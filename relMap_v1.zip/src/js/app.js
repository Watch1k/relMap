//=include lib/jquery.min.js
//=include lib/jquery-ui.min.js
//=include lib/tagtacular.min.js
//=include lib/svg4everybody.min.js
//=include lib/common.js
